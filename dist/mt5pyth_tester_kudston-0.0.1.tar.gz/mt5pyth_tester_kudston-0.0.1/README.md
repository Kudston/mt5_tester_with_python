##########
A custom metatrader 5 strategy tester designed by @kudston

Description:
    - if You have a script of mt5 integrated python program, you can easily mask the mt5 module with our module here and be able to test using our currently tick based tester.